import pandas as pd
sInputFileName="C:\\Users\\ROHIT\\Pictures\\Drive D\\Sem 1\\data science P\\rohit d_s practical\\practical1\\Country_Code.csv"
InputData=pd.read_csv(sInputFileName,encoding="latin-1")
print('Input Data Values ===================================')
print(InputData)
print('=====================================================')
ProcessData=InputData
ProcessData.drop('ISO-2-CODE', axis=1,inplace=True)
ProcessData.drop('ISO-3-Code', axis=1,inplace=True)
ProcessData.rename(columns={'Country': 'CountryName'}, inplace=True)
ProcessData.rename(columns={'ISO-M49': 'CountryNumber'}, inplace=True)
ProcessData.set_index('CountryNumber', inplace=True)
ProcessData.sort_values('CountryName', axis=0, ascending=False, inplace=True)
print('Process Data Values =================================')
print(ProcessData)
print('=====================================================')
OutputData=ProcessData
sOutputFileName="C:\\Users\\ROHIT\\Pictures\\Drive D\\Sem 1\\data science P\\rohit d_s practical\\practical1\\CSV TO HORUS.csv"
OutputData.to_csv(sOutputFileName, index = False)
print('CSV to HORUS - Done')
